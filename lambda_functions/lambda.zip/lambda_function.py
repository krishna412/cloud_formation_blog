# Time taken for the entire function- 1 min 43 seconds
import pandas as pd
import boto3
from io import StringIO

def lambda_handler(event, context):
    print('hello')